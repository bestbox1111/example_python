import pyautogui

# pip install pyautogui 해야사용가능.


pyautogui.moveTo(148,775,2)
pyautogui.click(clicks=2)

pyautogui.moveTo(626,637,2)
pyautogui.click()

pyautogui.moveTo(1061,521,1)
pyautogui.click()

pyautogui.moveTo(863,692,1)
pyautogui.click()

